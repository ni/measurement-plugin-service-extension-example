"""Python wrapper for Bench Data Connector Datalogging."""
# flake8: noqa: E402
# pyright: reportMissingImports=false

import datetime
from enum import Enum
import gc
import os
import sys
from typing import List

import clr

DLL_FOLDER_PATH = os.path.join(
    "C:\\",
    "Program Files",
    "National Instruments",
    "Bench Data Connector",
    "Datalogger",
    "DotNET DLLs",
)

if os.path.exists(DLL_FOLDER_PATH):
    sys.path.append(DLL_FOLDER_PATH)
else:
    raise Exception(
        "Bench Data Connector - Datalogging library is not properly installed, please re-install and try again"
    )

clr.AddReference("NationalInstruments.BDCDataloggerCore")
clr.AddReference("DataHandler")
clr.AddReference("System")
clr.AddReference("System.Collections")


from DataHandler.Common import AttachmentDetails
from DataHandler.Common import MeasurementDetails as DLL_MeasurementDetails
from DataHandler.Common import Waveform as DLL_Waveform
from DataHandler.Common import WaveformDetails as DLL_WaveformDetails
from DataHandler.Common import XYData as DLL_XYData
from DataHandler.Common import XYDataDetails as DLL_XYDataDetails
from DataHandler.Common import XDataAndMultipleYData as DLL_XDataAndMultipleYData
from DataHandler.Common import XDataAndMultipleYDataDetails as DLL_XDataAndMultipleYDataDetails
from NationalInstruments.BDCDataloggerCore import Datalogger
from System import Array, DateTime, Double, String
from System.Collections.Generic import Dictionary
from System.Collections.Generic import List as SystemList

datalogger = None

from dataclasses import dataclass


@dataclass
class MeasurementDetails:
    """Measurement details.

    Attributes:
        name (str): Name of the measurement.
        spec_id (str): Spec ID of the measurement.
        unit (str): Unit of the measurement.
        value (float): Value of the measurement.
        high_limit (float, optional): expected High Limit of the measurement. Defaults to None.
        low_limit (float, optional): expected Low Limit of the measurement. Defaults to None.
        nominal_value (float, optional): expected Nominal Value of the measurement.
        Defaults to None.
    """

    name: str
    spec_id: str
    value: float
    unit: str
    high_limit: float = None
    low_limit: float = None
    nominal_value: float = None


@dataclass
class Channel:
    """Channel

    Attributes:
        name (str): Name of the channel.
        data (List[float]): 1D array of data of the channel.
        unit (str, optional): Unit of the channel.
    """

    name: str
    data: List[float]
    unit: str = None


@dataclass
class Series:
    """Series

    Attributes:
        t0 (datetime): Start time of the series.
        dt (float): Time interval between two consecutive samples.
    """

    t0: datetime
    dt: float


@dataclass
class XYData:
    """XY Data.

    Attributes:
        x (Channel): X channel.
        y (Channel): Y channel.
        name (str): Name of the XY data.
    """

    x: Channel
    y: Channel
    name: str


@dataclass
class XAndMultipleYData:
    """X and multiple Y data.

    Attributes:
        x (Channel): x axis Channel data.
        y_list (List[Channel]): list of y axis Channel data.
        name (str): Name of the XY data
    """

    x: Channel
    y_list: List[Channel]
    name: str


@dataclass
class Waveform:
    """Waveform Details.

    Attributes:
        name (str): Group Name in the Tdms file.
        x (Series): X axis details as Series object.
        y (Channel): Waveform data as Channel object
        attributes (dict, optional): List of channel attributes will be logged in the Tdms file
                        along with the corresponding channel data.
                        Defaults to None.
    """

    name: str
    x: Series
    y: Channel
    attributes: dict = None


class Fields(str, Enum):
    """Metadata fields"""

    DeviceIdentifier = "DeviceIdentifier"
    RunId = "RunId"
    SpecProductId = "SpecProductId"
    ProductName = "ProductName"
    ProductRevision = "ProductRevision"
    PackageType = "PackageType"
    LotName = "LotName"
    ChipId = "ChipId"
    ProgramName = "ProgramName"
    TestBench = "TestBench"
    Operator = "Operator"
    Lab = "Lab"
    StartTime = "StartTime"
    FinishTime = "FinishTime"
    RunComment = "RunComment"
    RunModeName = "RunModeName"

    def __str__(self) -> str:
        return str.__str__(self)


class ConvertMeasurementDetails:
    """Convert MeasurementDetails to DLL MeasurementDetails"""

    def _convert_measurement_details_(
        self, measurement_details: MeasurementDetails
    ) -> DLL_MeasurementDetails:
        dll_measurement_details = DLL_MeasurementDetails()
        dll_measurement_details.MeasurementName = measurement_details.name
        dll_measurement_details.SpecID = measurement_details.spec_id
        dll_measurement_details.Value = Double.Parse(str(measurement_details.value))
        dll_measurement_details.Unit = measurement_details.unit
        if measurement_details.high_limit is not None:
            dll_measurement_details.HighLimit = measurement_details.high_limit
        if measurement_details.low_limit is not None:
            dll_measurement_details.LowLimit = measurement_details.low_limit
        if measurement_details.nominal_value is not None:
            dll_measurement_details.NominalValue = measurement_details.nominal_value
        return dll_measurement_details


class TestRun(ConvertMeasurementDetails):
    """Bench Data Connector - Datalogger"""

    def __init__(
        self,
        folder_path: str,
        file_name: str = "",
        metadata: dict = {},
    ) -> None:
        """Initialize datalogging session.

        Initializes the datalogging session and creates the datalog output file in the specified
        location with the provided file_name. Also adds in the metadata headers and values.

        (Expects metadata "ProductName" when file_name is not provided)

        Args:
            folder_path (str): Folder path of the datalog files
            file_name (str, optional): Name of the file. Defaults to ""
            metadata (dict(Fields, str)): Dictionary of run level metadata to be added.
            Defaults to Validation_(ProductName)_YYYY-MM-DD_HH:MM:SS.csv

        """
        global datalogger
        if datalogger is None:
            datalogger = Datalogger()

        metadata_dict = Dictionary[String, String]()
        warnings = []

        for key, value in metadata.items():
            if isinstance(key, Fields):
                metadata_dict[key.value] = value
            else:
                warnings.append(key)

        if warnings:
            print(
                "Warning: Metadata keys should be of type Fields. "
                "Ignoring the following metadata:\n"
                f"{warnings}"
            )
        datalogger.InitializeDatalog(
            metadataHeadersAndValues=metadata_dict,
            folderPath=folder_path,
            fileName=file_name,
        )

    def __enter__(self):
        return self

    def __exit__(self, exc_type, exc_value, exc_traceback):
        """Close datalogging session."""
        self.close_datalog()

    def close_datalog(self) -> None:
        """Close datalogging session."""
        global datalogger
        datalogger.CloseDatalog()
        datalogger = None

    def log_measurement(self, measurement: MeasurementDetails):
        """Log measurement.

        Args:
            measurement (MeasurementDetails): MeasurementDetails object to be logged.
        """
        datalogger.LogMeasurement(
            measurementDetails=self._convert_measurement_details_(measurement_details=measurement),
        )

    def log_multiple_measurements(self, measurements_list: List[MeasurementDetails]):
        """Log Multiple Measurements.

        Args:
            measurements_list (List[MeasurementDetails]): List of MeasurementDetails objects to be logged.
        """
        dll_measurement_details_list = list()

        for measurement in measurements_list:
            dll_measurement_details_list.append(self._convert_measurement_details_(measurement))

        datalogger.LogMultipleMeasurements(
            multipleMeasurementDetails=dll_measurement_details_list,
        )

    class Metadata:
        """Set Measurement Parameters and Metadata"""

        __parameters: List[str]
        __metadata: List[str]
        __info_data: List[str]

        def __init__(self):
            self.__parameters = []
            self.__metadata = []
            self.__info_data = []

        def __enter__(self):
            return self

        def __exit__(self, exc_type, exc_value, exc_traceback):
            self.remove_all_metadata()
            self.remove_all_parameters()
            self.remove_all_additional_info()

        def __validate_column_name(self, column_name: str, column_list: List[str]) -> bool:
            """Validate the column name.

            Args:
                column_name (str): Column name to be validated
                column_list (List[str]): List of column names

            Returns:
                bool: True if column name is valid, else False

            """
            if column_list:
                column_list = [column.lower() for column in column_list]
            return not column_name.strip().lower() in column_list

        def get_parameters(self) -> List[str]:
            """Get list of parameters added so far.

            Returns:
                parameters[List[str]]: List of parameters added so far.
            """
            return self.__parameters

        def get_metadata(self) -> List[str]:
            """Get list of metadata added so far.

            Returns:
                metadata[List[str]]: List of metadata added so far.
            """
            return self.__metadata

        def get_info_data(self) -> List[str]:
            """Get list of information added so far

            Returns:
                info_data[List[str]]: List of information added so far
            """
            return self.__info_data

        def add_string_parameter(self, parameter_name: str, parameter_value: str) -> None:
            """Add a string parameter.

            If a parameter with the same name has already been added, then the
            parameter value will be replaced.

            Args:
                parameter_name (str): Name of parameter to be added.
                parameter_value (str): Value of the parameter to be added.

            """
            datalogger.AddStringParameter(
                parameterName=parameter_name, parameterValue=parameter_value
            )
            if self.__validate_column_name(
                column_name=parameter_name, column_list=self.__parameters
            ):
                self.__parameters.append(parameter_name.strip())

        def add_numeric_parameter(self, parameter_name: str, parameter_value: float, parameter_unit: str = "") -> None:
            """Add a numeric parameter.

            If a parameter with the same name and same unit has already been added, then the
            parameter value will be replaced.

            Args:
                parameter_name (str): Name of parameter
                parameter_value (float): Value of parameter
                parameter_unit (str): Unit of parameter.

            """
            datalogger.AddNumericParameter(
                parameterName=parameter_name,
                parameterValue=parameter_value,
                parameterUnit=parameter_unit,
            )

            if self.__validate_column_name(
                column_name=parameter_name, column_list=self.__parameters
            ):
                self.__parameters.append(parameter_name.strip())

        def add_additional_info(self, info_name: str, info_value: str) -> None:
            """Add a information data

            If the information with the same name has already been added, then the
            infomation value will be replaced.

            Args:
                info_name (str): Name of the information to be added.
                info_value (str): Value of the information to be added.

            """
            datalogger.AddAdditionalInfo(
                infoName=info_name, infoValue=info_value
            )
            if self.__validate_column_name(
                column_name=info_name, column_list=self.__info_data
            ):
                self.__info_data.append(info_name.strip())

        def remove_parameter(self, parameter_name: str) -> None:
            """Remove the parameter given as parameter_name.

            Args:
                parameter_name (str): Name of the parameter to be removed.

            """
            datalogger.RemoveParameter(parameterName=parameter_name)
            if not self.__validate_column_name(
                column_name=parameter_name, column_list=self.__parameters
            ):
                if parameter_name.strip() in self.__parameters:
                    self.__parameters.remove(parameter_name.strip())

        def remove_additional_info(self, info_name: str) -> None:
            """Remove the information given as info_name

            Args:
                info_name (str): Name of the information data to be removed.
            """
            datalogger.RemoveAdditionalInfo(infoName=info_name)
            if not self.__validate_column_name(
                column_name=info_name, column_list=self.__info_data
            ):
                if info_name.strip() in self.__info_data:
                    self.__info_data.remove(info_name.strip())
        
        def remove_all_parameters(self) -> None:
            """Remove all the parameters added."""
            for parameter in set(self.__parameters):
                self.remove_parameter(parameter_name=parameter)
            self.__parameters = []

        def remove_all_additional_info(self) -> None:
            """Remove all the info parameters added."""
            for infomation in set(self.__info_data):
                self.remove_additional_info(info_name=infomation)
            self.__info_data = []
        
        def add_metadata(self, metadata_name: Fields, metadata_value: str) -> None:
            """Add metadata.

            If a meta data with the same name has already been added, then the metadata
            value will be replaced.

            Args:
                metadata_name (Fields): Name of the metadata to be added.
                metadata_value (str): Value of the metadata to be added.

            """
            if isinstance(metadata_name, Fields):
                datalogger.AddMetadata(
                    metadataName=metadata_name.value, metadataValue=metadata_value
                )
                if metadata_name not in self.__metadata:
                    self.__metadata.append(metadata_name)
            else:
                print(
                    f"Warning: Metadata name: '{metadata_name}' should be of type Fields."
                    " Metadata not added."
                )

        def remove_metadata(self, metadata_name: Fields) -> None:
            """Remove the metadata matching metadata_name.

            Args:
                metadata_name (Fields): metadata field to be removed

            """
            if isinstance(metadata_name, Fields):
                datalogger.RemoveMetadata(metadataName=metadata_name.value)
                self.__metadata.remove(metadata_name)
            else:
                print(
                    f"Warning: Metadata name: '{metadata_name}' should be of type Fields."
                    " Metadata not removed."
                )

        def remove_all_metadata(self) -> None:
            """Remove all the metadata added."""
            for metadata in set(self.__metadata):
                self.remove_metadata(metadata_name=metadata)
            self.__metadata = []

    class AuxiliaryFiles:
        """Create auxiliary files."""

        _attachment_objects: List[AttachmentDetails]

        def __init__(self):
            self._attachment_objects = []

        def get_number_of_attachments(self) -> int:
            """Get number of attachments added so far.

            Returns:
                number_of_attachments (int): Number of attachments
            """
            return len(self._attachment_objects)

        def __convert_xy_data_list__(self, xy_data_list: List[XYData]) -> List[DLL_XYData]:
            dll_xy_data_list = list()

            for index, xy_data in enumerate(xy_data_list):
                dll_xy_data = DLL_XYData()

                dll_xy_data.XAxisName = xy_data.x.name
                dll_xy_data.XData = xy_data.x.data

                dll_xy_data.YAxisName = xy_data.y.name
                dll_xy_data.YData = xy_data.y.data

                dll_xy_data.XYName = xy_data.name

                if xy_data.x.unit:
                    dll_xy_data.XUnit = xy_data.x.unit
                if xy_data.y.unit:
                    dll_xy_data.YUnit = xy_data.y.unit

                dll_xy_data_list.append(dll_xy_data)
            return dll_xy_data_list

        def __convert_x_and_multiple_y_data_list__(
            self, x_and_multiple_y_data_list: List[XAndMultipleYData]
        ) -> List[DLL_XDataAndMultipleYData]:

            dll_x_and_multiple_y_data_list = list()

            for index, x_and_multiple_y_data in enumerate(x_and_multiple_y_data_list):
                dll_x_and_multiple_y_data = DLL_XDataAndMultipleYData()

                dll_x_and_multiple_y_data.XData = x_and_multiple_y_data.x.data
                dll_x_and_multiple_y_data.XAxisName = x_and_multiple_y_data.x.name

                y_list = Dictionary[String, SystemList[Double]]()
                y_units_list = []

                for y in x_and_multiple_y_data.y_list:
                    y_data_system_array = Array[Double](y.data)
                    y_data_system_list = SystemList[Double](y_data_system_array)
                    y_list.Add(y.name, y_data_system_list)
                    if y.unit:
                        y_units_list.append(y.unit)

                dll_x_and_multiple_y_data.MultipleYData = y_list
                y_list = None
                gc.collect()

                dll_x_and_multiple_y_data.XYName = x_and_multiple_y_data.name
                if x_and_multiple_y_data.x.unit:
                    dll_x_and_multiple_y_data.XUnit = x_and_multiple_y_data.x.unit

                dll_x_and_multiple_y_data.YUnit = y_units_list
                dll_x_and_multiple_y_data_list.append(dll_x_and_multiple_y_data)
            return dll_x_and_multiple_y_data_list

        def __convert_waveform_details__(self, waveform_details: Waveform) -> DLL_WaveformDetails:
            dll_waveform_details = DLL_WaveformDetails()

            waveform = DLL_Waveform()
            waveform.dt = waveform_details.x.dt
            t0 = waveform_details.x.t0
            waveform.T0 = DateTime(*t0.timetuple()[:6] + (int(t0.microsecond / 1000),))
            waveform.Y = waveform_details.y.data

            if waveform_details.attributes is not None:
                waveform_attributes_dict = Dictionary[String, String]()
                for key, value in waveform_details.attributes.items():
                    waveform_attributes_dict[key] = value
                waveform.Attributes = waveform_attributes_dict

            dll_waveform_details.Group = waveform_details.name
            dll_waveform_details.Channel = waveform_details.y.name
            dll_waveform_details.Unit = waveform_details.y.unit
            dll_waveform_details.Waveform = waveform

            return dll_waveform_details

        def attach_file(self, source_file_path: str) -> None:
            """Attach file to the measurement log.

            Includes the auxiliary file path along with the Measurements.

            Also copies the specified file from the source location parallel to the current run with
            the folder name same as the run file name.

            Args:
                source_file_path (str): Path of the source file to be attached.
            """
            self._attachment_objects.append(datalogger.AttachFile(sourceFile=source_file_path))

        def attach_xy_data(
            self,
            root_name: str,
            xy_data: List[XYData],
            root_attributes: dict = {},
        ) -> None:
            """Attach XY Data to the measurement log.

            Creates a Tdms file for the given XY data details.

            Also, includes the file path of the Tdms file along with the Measurements.

            Args:
                root_name (str): TDMS Root name of the file.
                xy_data (List[XYData]): List of XY data to be attached.
                root_attributes (dict, optional): List of root attributes will be logged in the Tdms file
                                                along with the Metadata. Defaults to empty dictionary.
            """

            xy_data_details = DLL_XYDataDetails()
            xy_data_details.RootName = root_name
            xy_data_details.XYData = self.__convert_xy_data_list__(xy_data)

            root_attributes_dict = Dictionary[String, String]()

            for key, value in root_attributes.items():
                root_attributes_dict[key] = value

            self._attachment_objects.append(
                datalogger.AttachXYData(xy_data_details, root_attributes_dict)
            )

        def attach_x_and_multiple_y_data(
            self,
            root_name: str,
            x_and_multiple_y_data: List[XAndMultipleYData],
            root_attributes: dict = {},
        ) -> None:
            """Attach single X and multiple Y axis data to the measurement log.

            Creates a Tdms file for the given XY data details.

            It also supports multiple Y channels for a single X channel. Also, includes the file path of the
            Tdms file along with the Measurements.

            Args:
                root_name (str): TDMS Root name of the file.
                x_and_multiple_y_data (List[XAndMultipleYData]): List of X and multiple Y data to be attached.
                root_attributes (dict, optional): List of root attributes will be logged in the Tdms file
                                                along with the Metadata. Defaults to None.
            """

            x_and_multiple_y_data_details = DLL_XDataAndMultipleYDataDetails()
            x_and_multiple_y_data_details.RootName = root_name
            x_and_multiple_y_data_details.XChannelAndMultipleYChannel = (
                self.__convert_x_and_multiple_y_data_list__(x_and_multiple_y_data)
            )

            root_attributes_dict = Dictionary[String, String]()

            for key, value in root_attributes.items():
                root_attributes_dict[key] = value

            gc.collect()

            self._attachment_objects.append(
                datalogger.AttachXAndMultipleYData(
                    x_and_multiple_y_data_details, root_attributes_dict
                )
            )

        def attach_single_waveform(
            self,
            root_name: str,
            waveform: Waveform,
            root_attributes: dict = {},
        ) -> None:
            """Attach single waveform to the measurement log.

            Creates a Tdms file for the given Waveform details.
            Also, includes the file path of the Tdms file along with the Measurements

            Args:
                root_name (str): Root name of the TDMS File.
                waveform (Waveform): Waveform details to be attached.
                root_attributes (dict, optional): List of root attributes will be logged in the
                                            Tdms file along with the Metadata. Defaults to None.
            """
            waveform_details = self.__convert_waveform_details__(waveform)

            root_attributes_dict = Dictionary[String, String]()

            for key, value in root_attributes.items():
                root_attributes_dict[key] = value

            self._attachment_objects.append(
                datalogger.AttachSingleWaveform(
                    singleWaveform=waveform_details,
                    rootName=root_name,
                    rootAttributes=root_attributes_dict,
                )
            )

        def attach_multiple_waveforms(
            self,
            root_name: str,
            waveforms: List[Waveform],
            root_attributes: dict = {},
        ) -> None:
            """Attach Multiple Waveforms.

            Creates a Tdms file for the given Waveform details.
            Also, includes the file path of the Tdms file along with the Measurements.

            Args:
                root_name (str): Root name of the TDMS File.
                waveforms (List[Waveform]): List of waveform details to be attached.
                root_attributes (dict, optional): List of root attributes will be logged in the Tdms file
                                                along with the Metadata. Defaults to None.
            """
            if len(waveforms) <= 0:
                raise Exception(
                    f"Error occurred while attaching MultipleWaveforms. Reason : waveforms cannot be empty."
                )

            multiple_waveform_details = list()

            for index, waveform in enumerate(waveforms):
                waveform_details = self.__convert_waveform_details__(waveform)
                multiple_waveform_details.append(waveform_details)

            root_attributes_dict = Dictionary[String, String]()

            for key, value in root_attributes.items():
                root_attributes_dict[key] = value

            self._attachment_objects.append(
                datalogger.AttachMultipleWaveforms(
                    multipleWaveform=multiple_waveform_details,
                    rootName=root_name,
                    rootAttributes=root_attributes_dict,
                )
            )

    class AttachableMeasurement(AuxiliaryFiles, ConvertMeasurementDetails):
        """Create Measurement."""

        details: MeasurementDetails

        def __init__(
            self,
            details: MeasurementDetails = None,
        ) -> None:
            """Create Measurement.

            Args:
                details (MeasurementDetails, optional): MeasurementDetails to be logged.
                                                     Defaults to None.
            """
            super().__init__()
            if details:
                self.details = details

        def __enter__(self):
            return self

        def __exit__(self, exc_type, exc_value, exc_traceback):
            self.write_measurement()

        def write_measurement(self) -> None:
            """Write measurement to the run file."""

            if self.details:
                datalogger.LogMeasurement(
                    measurementDetails=self._convert_measurement_details_(
                        measurement_details=self.details
                    ),
                    attachmentObjects=self._attachment_objects,
                )
                self.details = None
            else:
                raise Exception(
                    "MeasurementDetails cannot be empty. Please add measurement details in the "
                    "constructor or by editing the 'details' property."
                )

    class AttachableMeasurements(AuxiliaryFiles, ConvertMeasurementDetails):
        """Create Multiple Measurements."""

        details_list: List[MeasurementDetails] = list()

        def __init__(self, details_list: List[MeasurementDetails] = []) -> None:
            """Create Multiple Measurements.

            Args:
                details_list (List[MeasurementDetails], optional): List of Measurements to be attached.
                                                                Defaults to [].
            """
            super().__init__()

            if details_list:
                self.details_list = details_list

        def __enter__(self):
            return self

        def __exit__(self, exc_type, exc_value, exc_traceback):
            self.write_measurements()

        def get_number_of_measurements(self) -> int:
            """Get number of measurements.

            Returns:
                number_of_measurements (int): Number of measurements
            """
            return len(self.details_list)

        def write_measurements(self) -> None:
            """Write measurements added so far to datalog file."""

            if self.details_list:
                dll_measurement_details_list = list()

                for measurement in self.details_list:
                    dll_measurement_details_list.append(
                        self._convert_measurement_details_(measurement)
                    )

                datalogger.LogMultipleMeasurements(
                    multipleMeasurementDetails=dll_measurement_details_list,
                    attachmentObjects=self._attachment_objects,
                )
                self.details_list = []

            else:
                raise Exception(
                    "Measurements cannot be empty. Please add measurement details in the "
                    "constructor or by editing the 'details_list' property."
                )
